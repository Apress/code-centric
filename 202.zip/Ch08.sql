--------------------------------------Ch 08 - Views
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--Creating Views
USE tempdb
go
CREATE VIEW vw_Customers
AS
SELECT CompanyName,
       City,
       Country
FROM Northwind..Customers


--*
USE tempdb
go
SELECT *
FROM vw_Customers


--*
USE tempdb
go
SELECT *
FROM vw_Customers
WHERE City = 'London'
ORDER BY CompanyName


--*
USE tempdb
go
CREATE VIEW vw_Customers_ContactName
AS
SELECT CompanyName,
       ContactName, 
       Phone,
       Fax 
FROM Northwind..Customers
go

SELECT *
FROM vw_Customers_ContactName
ORDER BY ContactName


--*
USE tempdb
go
CREATE VIEW vw_Customers_OrderDetail
AS
SELECT a.CompanyName,
       b.OrderID,
       b.EmployeeID, 
       d.ProductName
FROM Northwind..Customers a
JOIN Northwind..Orders b ON a.CustomerID = b.CustomerID
JOIN Northwind..[Order Details] c ON b.OrderID = c.OrderID
JOIN Northwind..Products d ON c.ProductID = d.ProductID


--*
USE tempdb
go
SELECT DISTINCT CompanyName
FROM vw_Customers_OrderDetail
WHERE ProductName = 'Geitost'


--*
USE tempdb
go
CREATE VIEW vw_Customers_OrderByEmployee
AS
SELECT DISTINCT a.CompanyName,
       a.OrderID,
       b.FirstName+b.LastName AS EmployeeName
FROM vw_Customers_OrderDetail a
JOIN Northwind..Employees b ON a.EmployeeID = b.EmployeeID
go

SELECT * 
FROM vw_Customers_OrderByEmployee



--Indexing Views
USE tempdb
go
CREATE CLUSTERED INDEX ndx_CompanyName
ON vw_Customers (CompanyName)


--*
USE Northwind
go
CREATE VIEW vw_Customers
WITH SCHEMABINDING
AS
SELECT CustomerID,
       CompanyName,
       City,
       Country
FROM dbo.Customers
go

CREATE UNIQUE CLUSTERED INDEX ndx_CompanyName
ON vw_Customers (CustomerID)


--*
USE Northwind
go
CREATE INDEX ndx_City
ON vw_Customers (City)


--Updating Data
--*
USE Northwind
go
UPDATE vw_Customers
SET CompanyName = CompanyName + '2'
WHERE CustomerID = 'ALFKI'

SELECT CompanyName
FROM customers
WHERE CustomerID = 'ALFKI'


--*
USE Northwind
go
CREATE VIEW vw_Customers_OrderDetail_2
AS
SELECT a.CustomerID,
       a.CompanyName,
       b.OrderID,
       b.ShipName,
       b.EmployeeID, 
       d.ProductName
FROM Customers a
JOIN Orders b ON a.CustomerID = b.CustomerID
JOIN [Order Details] c ON b.OrderID = c.OrderID
JOIN Products d ON c.ProductID = d.ProductID
go

UPDATE vw_Customers_OrderDetail_2
SET CompanyName = CompanyName + '2',
    ShipName = ShipName + '2'
WHERE CustomerID = 'ALFKI' AND
      OrderID = 10643



--*
USE Northwind
go
UPDATE vw_Customers_OrderDetail_2
SET CompanyName = CompanyName + '2'
WHERE CustomerID = 'ALFKI' 

UPDATE vw_Customers_OrderDetail_2
SET ShipName = ShipName + '2'
WHERE OrderID = 10643

SELECT CompanyName
FROM Customers
WHERE CustomerID = 'ALFKI'

SELECT ShipName
FROM Orders
WHERE OrderID = 10643


--*
USE Northwind
go
CREATE VIEW vw_Employees
AS
SELECT EmployeeID,
       LastName,
       FirstName,
       Title
FROM Employees
go

SELECT *
FROM vw_Employees


--*
USE Northwind
go
INSERT vw_Employees 
(
 LastName,
 Title
)
VALUES 
(
 'Woods',
 'Vice President, Manufacturing'
)


--*
USE Northwind
go
INSERT vw_Employees 
(
 LastName,
 FirstName,
 Title
)
VALUES 
(
 'Woods',
 'Natalie',
 'Vice President, Manufacturing'
)

SELECT  LastName,
        FirstName,
        Title
FROM Employees
WHERE EmployeeID = @@IDENTITY


--Altering Views
--*
USE Northwind
go
ALTER VIEW vw_Employees
AS
SELECT a.FirstName+' '+a.LastName AS EmployeeName,
       COUNT(b.OrderID) AS OrderCount
FROM Employees a
LEFT JOIN Orders b ON a.EmployeeID = b.EmployeeID
GROUP BY a.FirstName+' '+a.LastName


--*
USE Northwind
go
sp_rename 'vw_Employees', 'vw_Employees_OrderCount'


--*
USE Northwind
go
SELECT *
FROM vw_Employees_OrderCount
ORDER BY OrderCount DESC


--Dropping Views
--*
USE Northwind
go
DROP VIEW vw_Employees_OrderCount, vw_Customers_OrderDetail_2


--Information Schema
--
USE Northwind
go
SELECT * 
FROM INFORMATION_SCHEMA.TABLES


--*
USE Northwind
go
SELECT PARAMETER_NAME, 
       ORDINAL_POSITION,
       PARAMETER_MODE
FROM INFORMATION_SCHEMA.PARAMETERS
WHERE SPECIFIC_NAME = 'Employee Sales by Country'

--------------------------------------End of Ch 08 - Views
