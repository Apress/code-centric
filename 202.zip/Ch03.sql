--------------------------------------*Ch 3 DDL
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--CREATE DATABASE
--*
USE master
go
CREATE DATABASE RealAdventures


--*
USE master
go
SELECT *
FROM sysdatabases
WHERE name = 'RealAdventures'


--*
USE master
go
DROP DATABASE RealAdventures
go
CREATE DATABASE RealAdventures
ON 
(NAME = 'RealAdventures',
 FILENAME = 'C:\MSSQL7\Data\RealAdventures.mdf',
 SIZE = 30 MB,
 MAXSIZE = 100 MB,
 FILEGROWTH = 15 MB)
LOG ON 
(NAME = 'RealAdventures_Log',
 FILENAME = 'C:\MSSQL7\Data\RealAdventures.ldf',
 SIZE = 10 MB,
 MAXSIZE = 25 MB,
 FILEGROWTH = 2 MB)


--*
USE RealAdventures
go
ALTER DATABASE RealAdventures
MODIFY FILE
(
 NAME = 'RealAdventures',
 SIZE = 50 MB,
 MAXSIZE = 150 MB
)


--*
USE RealAdventures
go
ALTER DATABASE RealAdventures SET READ_ONLY


--*
USE master
go
--Create two dummy database
CREATE DATABASE RealAdventures2
CREATE DATABASE RealAdventures3
go
--Delete dummy databases
DROP DATABASE RealAdventures2, RealAdventures3


--CREATE TABLE
--*
USE master
go
CREATE DATABASE BrokerExample
ON 
(NAME = 'BrokerExample',
 FILENAME = 'C:\MSSQL7\Data\BrokerExample.mdf',
 SIZE = 10 MB,
 MAXSIZE = 25 MB,
 FILEGROWTH = 5 MB)
LOG ON 
(NAME = 'BrokerExample_Log',
 FILENAME = 'C:\MSSQL7\Data\BrokerExample.ldf',
 SIZE = 5 MB,
 MAXSIZE = 10 MB,
 FILEGROWTH = 2 MB)
go
USE BrokerExample
go
sp_addtype 'address', 'varchar(40)', 'NOT NULL'
go
sp_addtype 'address2', 'varchar(40)', 'NULL'
go
sp_addtype 'city', 'varchar(35)', 'NOT NULL'
go
sp_addtype 'zip', 'varchar(15)', 'NOT NULL'
go
sp_addtype 'phone', 'varchar(10)', 'NOT NULL'
go
sp_addtype 'mobile', 'varchar(10)', 'NULL'
go


--*
USE BrokerExample
go
CREATE TABLE States
(
 Sta_UniqueID tinyint PRIMARY KEY IDENTITY,
 Sta_Name varchar(30)
)

CREATE TABLE BrokerFirms
(
 BroFir_UniqueID tinyint PRIMARY KEY IDENTITY,
 BroFir_Name varchar(40) NOT NULL,
 BroFir_Address address,
 BroFir_Address2 address2,
 BroFir_City city NOT NULL,
 Sta_UniqueID tinyint,
 BroFir_Zip zip,
 BroFir_Phone phone,
 BroFir_Fax phone,
 BroFir_WebSite varchar(50) NULL,
)

CREATE TABLE Brokers
(
 Bro_UniqueID smallint PRIMARY KEY IDENTITY,
 BroFir_UniqueID tinyint NOT NULL,
 Bro_FName varchar(30) NOT NULL,
 Bro_LName varchar(30) NOT NULL,
 Bro_Address address2,
 Bro_Address2 address2,
 Bro_City city,
 Sta_UniqueID tinyint, 
 Bro_Zip zip,
 Bro_Phone phone,
 Bro_Mobile phone,
 Bro_email varchar(40) NULL
)


--*
USE BrokerExample
go
ALTER TABLE Brokers
ALTER COLUMN Bro_Address address


--*
USE BrokerExample
go
sp_help 'Brokers'


--*
USE BrokerExample
go
ALTER TABLE Brokers
ADD Bro_Pager varchar(15)


--*
USE BrokerExample
go
ALTER TABLE Brokers
ADD Bro_Pager2 varchar(15) NOT NULL


--*
USE BrokerExample
go
ALTER TABLE Brokers
ADD Bro_Pager2 varchar(15) NOT NULL DEFAULT 'NONE'


--*
USE BrokerExample
go
ALTER TABLE BrokerFirms
ADD CONSTRAINT BrokerFirms_States
FOREIGN KEY (Sta_UniqueID) REFERENCES States (Sta_UniqueID)

ALTER TABLE Brokers
ADD CONSTRAINT Brokers_States
FOREIGN KEY (Sta_UniqueID) REFERENCES States (Sta_UniqueID)

ALTER TABLE Brokers
ADD CONSTRAINT Brokers_BrokerFirms
FOREIGN KEY (BroFir_UniqueID) REFERENCES BrokerFirms (BroFir_UniqueID)


--*
USE BrokerExample
go
ALTER TABLE Brokers
DROP CONSTRAINT Brokers_States

ALTER TABLE Brokers
ADD 
FOREIGN KEY (Sta_UniqueID) REFERENCES States (Sta_UniqueID)


--*
sp_help 'Brokers'


--CREATE INDEX
--*
USE BrokerExample
go
CREATE NONCLUSTERED INDEX ndx_Brokers_LName
ON Brokers (Bro_LName)


--*
USE BrokerExample
go
DROP INDEX Brokers.ndx_Brokers_LName

--------------------------------------*End of Ch 3 DDL