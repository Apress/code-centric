--------------------------------------*Appendix C - Query Optimization
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--Searchable Arguments
--*
USE Northwind
go
SELECT CompanyName
FROM Customers
WHERE Country = 'Mexico'


--*
USE Northwind
go
SELECT CompanyName,
       Country
FROM Customers
WHERE SUBSTRING(Country,1,1) = 'A'


--*
USE Northwind
go
sp_helpindex 'Customers'


--*
SELECT CompanyName
FROM Customers
WHERE Country = 'Mexico'


--*
CREATE NONCLUSTERED INDEX ndx_CustomersCountry
ON Customers (Country)


--*
SELECT CompanyName
FROM Customers
WHERE Country = 'Mexico'


--*
SELECT CompanyName
FROM Customers
WHERE SUBSTRING(Country,1,1) = 'A'


--*
SELECT CompanyName
FROM Customers
WHERE Country LIKE 'A%'


--*
SELECT CompanyName
FROM Customers
WHERE Country LIKE '_A%'



--Determining the Most Efficient Query
--Query 1 -- LEFT JOIN
SELECT CompanyName
FROM Customers a
LEFT JOIN ORDERS b ON a.CustomerID = b.CustomerID
WHERE b.CustomerID IS NULL

--Query 2 -- NOT EXISTS
SELECT CompanyName
FROM Customers a
WHERE NOT EXISTS (SELECT *
                  FROM Orders b
                  WHERE a.CustomerID = b.CustomerID)

--Query 3 -- NOT IN
SELECT CompanyName
FROM Customers
WHERE CustomerID NOT IN (SELECT CustomerID
                         FROM Orders)


--*
SELECT * 
INTO Orders2
FROM Orders
go
INSERT Orders2
SELECT CustomerID,
       EmployeeID,
       OrderDate,
       RequiredDate,
       ShippedDate,
       ShipVia,
       Freight,
       ShipName,
       ShipAddress,
       ShipCity,
       ShipRegion,
       ShipPostalCode,
       ShipCountry
FROM Orders



--*
--Query 1 -- LEFT JOIN
SELECT CompanyName
FROM Customers a
LEFT JOIN ORDERS2 b ON a.CustomerID = b.CustomerID
WHERE b.CustomerID IS NULL

--Query 2 -- NOT EXISTS
SELECT CompanyName
FROM Customers a
WHERE NOT EXISTS (SELECT *
                  FROM Orders2 b
                  WHERE a.CustomerID = b.CustomerID)

--Query 3 -- NOT IN
SELECT CompanyName
FROM Customers
WHERE CustomerID NOT IN (SELECT CustomerID
                         FROM Orders2)



--Index Tuning Wizard
--*
USE Northwind
go
SELECT *
FROM Orders2


--*
SELECT *
FROM Orders2
WHERE CustomerID = 'CENTC'


--*
UPDATE Orders2
SET ShipName = 'El Centro Rocket Shop' 
WHERE CustomerID = 'VICTE'


--*
SELECT *
FROM Orders2
WHERE CustomerID = 'VICTE'


--*
DROP INDEX Orders2.Orders21


--*
SELECT *
FROM Orders2 
WHERE ShipName LIKE 'A%'
ORDER BY ShipName

--------------------------------------*End of Appendix C - Query Optimization