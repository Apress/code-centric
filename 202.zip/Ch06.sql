--------------------------------------*Ch 06 - T-SQL Built-In Functions
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--Database Compatibility Levels
--*
USE Northwind
go
sp_dbcmptlevel 'Northwind'


--*
USE Northwind
go
sp_dbcmptlevel 'Northwind','65'
go
sp_dbcmptlevel 'Northwind'
go
sp_dbcmptlevel 'Northwind','80'
go
sp_dbcmptlevel 'Northwind'


--*NOTE: Execute the following to turn off rowcounts from being returned
SET NOCOUNT ON


--STRING FUNCTIONS
--*
SELECT ASCII('W'), ASCII('w')


--*
USE tempdb
go
CREATE TABLE #CaseSensitive (Descriptor varchar(10))
go
INSERT #CaseSensitive VALUES ('sosa')
INSERT #CaseSensitive VALUES ('Sosa')
go
DECLARE @Descriptor varchar(10)
SET @Descriptor = 'Sosa'

SELECT Descriptor
FROM #CaseSensitive
WHERE Descriptor = @Descriptor AND
      ASCII(Descriptor) = ASCII(@Descriptor)


--*
DECLARE @Descriptor varchar(10)
SET @Descriptor = 'Sosa'

SELECT Descriptor
FROM #CaseSensitive
WHERE CAST(Descriptor AS varbinary) = CAST(@Descriptor AS varbinary)


--*
DECLARE @Value smallint
SET @Value = 33
WHILE @Value <= 126
 BEGIN
  PRINT CHAR(@Value) 
  SET @Value = @Value + 1
 END


--*
DECLARE @String varchar(25)
SET @String = '1,2,3,4'
SELECT CHARINDEX(',',@String)


--*
DECLARE @String varchar(25)
SET @String = '1,2,3,4'
SELECT CHARINDEX(',',@String,3)


--*
DECLARE @String varchar(25)
SET @String = 'A329--Big Bertha 9'
SELECT CHARINDEX('--',@String)


--*
DECLARE @String varchar(25)
SET @String = '1,2,3,4'
SELECT LEFT(@String,4)


--*
DECLARE @String varchar(25)
SET @String = '1,2,3,4'
SELECT LEN(@String)


--*
DECLARE @String varchar(10)
SET @String = 'GRIFFEY'
SELECT LOWER(@String)


--*
USE tempdb
go
CREATE TABLE #LTRIM_Example (Descriptor varchar(10))
go
INSERT #LTRIM_Example VALUES ('  Sosa')
SELECT Descriptor FROM #LTRIM_Example
SELECT LTRIM(Descriptor) FROM #LTRIM_Example


--*
SELECT Descriptor 
FROM #LTRIM_Example
WHERE Descriptor = 'Sosa'


--*
UPDATE #LTRIM_Example
SET Descriptor = SUBSTRING(Descriptor,2,LEN(Descriptor))
WHERE SUBSTRING(Descriptor,1,1) = ' '


--*
SELECT NCHAR(202)


--*
USE tempdb
go
CREATE TABLE #PATINDEX_Example (Descriptor varchar(100))
go
INSERT #PATINDEX_Example VALUES ('Baseball is as American as apple pie')

SELECT PATINDEX('%merica%',Descriptor)
FROM #PATINDEX_Example


--*
INSERT #PATINDEX_Example VALUES ('The Dallas Cowboys are America''s team')
INSERT #PATINDEX_Example VALUES ('Tiger Woods is the world''s greatest golfer')

SELECT Descriptor
FROM #PATINDEX_Example
WHERE PATINDEX('%merica%',Descriptor) > 0


--*
DECLARE @ParentString varchar(50)
SET @ParentString = 'Tiger Woods is the world''s greatest golfer'
SELECT REPLACE (@ParentString, 'o' , 'x' )


--*
SELECT REVERSE ('Tiger Woods is the world''s greatest golfer') 


--*
DECLARE @String varchar(25)
SET @String = '1,2,3,4'
SELECT CHARINDEX(',',REVERSE(@String))


--*
SELECT RIGHT(Descriptor,10) FROM #PATINDEX_Example


--*
CREATE TABLE #RIGHT_Example (Descriptor char(10))
go
INSERT #RIGHT_Example VALUES ('1234567890')
INSERT #RIGHT_Example VALUES ('12345')
go
SELECT RIGHT(Descriptor,5)
FROM #RIGHT_Example


--*
SELECT RIGHT(RTRIM(Descriptor),5)
FROM #RIGHT_Example


--*
DECLARE @Value float
SELECT @Value = 4534.876

SELECT STR(@Value)
SELECT STR(@Value,6,1)
SELECT STR(@Value,8,3)


--*
DECLARE @Value varchar(25)
SET @Value = 'A342-Titlest 975D'

SELECT SUBSTRING(@Value,6,25)


--*
CREATE TABLE #SUBSTR_Example (Descriptor varchar(35))
go
INSERT #SUBSTR_Example VALUES ('A432-Titlest 975D')
INSERT #SUBSTR_Example VALUES ('B1432-Scotty Cameron Putter')
INSERT #SUBSTR_Example VALUES ('C14-Golden Bear Irons')

SELECT SUBSTRING(Descriptor, CHARINDEX('-',Descriptor)+1,25) AS ProductDescription
FROM #SUBSTR_Example


--*
SELECT UNICODE('���������')


--*
DECLARE @String varchar(10)
SET @String = 'griffey'
SELECT UPPER(@String)


--Date Functions
--*
DECLARE @DateValue datetime 
SET @DateValue = '1/1/2000'
SELECT @DateValue


--*
DECLARE @DateValue datetime 
SET @DateValue = '11:00:00.000'
SELECT @DateValue


--*
DECLARE @DateValue datetime 
SET @DateValue = '1/1/50'
SELECT @DateValue


--*
DECLARE @DateValue datetime 
SET @DateValue = '1/1/49'
SELECT @DateValue


--*
DECLARE @DateValue smalldatetime
SET @DateValue = '10/22/99'
SELECT DATEADD(year,1,@DateValue)
SELECT DATEADD(quarter,1,@DateValue)
SELECT DATEADD(month,1,@DateValue)
SELECT DATEADD(week,1,@DateValue)
SELECT DATEADD(day,1,@DateValue)
SELECT DATEADD(hour,1,@DateValue)


--*
USE Northwind
go
DECLARE @DateStart smalldatetime,
        @RangeValue smallint
SET @DateStart = '4/1/98'
SET @RangeValue = 10

SELECT COUNT(OrderDate)
FROM Orders
WHERE OrderDate BETWEEN @DateStart AND DATEADD(day,@RangeValue,@DateStart)


--*
DECLARE @StartDate smalldatetime, @EndDate smalldatetime
SET @StartDate = '2/1/00'
SET @EndDate = '6/24/00'

SELECT DATEDIFF(month,@StartDate,@EndDate)
SELECT DATEDIFF(week,@StartDate,@EndDate)
SELECT DATEDIFF(day,@StartDate,@EndDate)
SELECT DATEDIFF(hour,@StartDate,@EndDate)


--*
USE Northwind
go
CREATE TABLE #DATEDIFF_Example (OrderDate smalldatetime, ShipDate smalldatetime)
go
INSERT #DATEDIFF_Example VALUES ('6/1/00','6/7/00')
INSERT #DATEDIFF_Example VALUES ('6/1/00','6/10/00')
INSERT #DATEDIFF_Example VALUES ('6/1/00',NULL)

SELECT OrderDate,ShipDate
FROM #DATEDIFF_Example
WHERE ShipDate IS NULL AND
      DATEDIFF(day,OrderDate,GETDATE()) > 10


--*
DECLARE @StartDate smalldatetime, @EndDate smalldatetime
SET @StartDate = '6/1/00'
SET @EndDate = '6/30/00'

WHILE @StartDate < @EndDate
 BEGIN
  PRINT DATENAME(weekday,@StartDate)
  SET @StartDate = DATEADD(day,1,@StartDate)
 END


--*
SELECT GETDATE() AS 'Date'
SELECT DATEPART(year,GETDATE()) AS 'year'
SELECT DATEPART(month,GETDATE()) AS 'month'
SELECT DATEPART(day,GETDATE()) AS 'day'
SELECT DATEPART(weekday,GETDATE()) AS 'weekday'
SELECT DATEPART(hour,GETDATE()) AS 'hour'
SELECT DATEPART(minute,GETDATE()) AS 'minute'


--*
DECLARE @StartDate smalldatetime, @EndDate smalldatetime, @Counter tinyint
SET @StartDate = '6/1/00'
SET @EndDate = '6/30/00'
SET @Counter= 0

WHILE @StartDate <= @EndDate
 BEGIN
  IF DATEPART(weekday,@StartDate) BETWEEN 2 AND 6
   BEGIN
     SET @Counter = @Counter + 1
   END

  SET @StartDate = DATEADD(day,1,@StartDate)
 END
PRINT @Counter


--*
SELECT DAY(GETDATE())


--*
SELECT GETDATE()


--*
SELECT GETUTCDATE()


--*
SELECT MONTH(GETDATE())


--*
SELECT YEAR(GETDATE())


--MATH FUNCTIONS
--*
DECLARE @Val1 numeric(5,2),@Val2 float
SET @Val1 = 54.09
SET @Val2 = -122.09343342

SELECT CEILING(@Val1)
SELECT CEILING(@Val2)


--*
DECLARE @Val float
SET @Val = -122.09343342

SELECT EXP(@Val)


--*
DECLARE @Val1 numeric(5,2),@Val2 float
SET @Val1 = 54.09
SET @Val2 = -122.09343342

SELECT FLOOR(@Val1)
SELECT FLOOR(@Val2)


--*
DECLARE @Val1 int,@Val2 tinyint
SET @Val1 = 22
SET @Val2 = 3

SELECT POWER(@Val1,@Val2)


--*
SET NOCOUNT ON
DECLARE @Val int
SET @Val = 3435493

SELECT RAND(@Val)


--*
DECLARE @Val decimal(9,4)
SET @Val = 6983.3639

SELECT ROUND(@Val,0)
SELECT ROUND(@Val,1)
SELECT ROUND(@Val,2)
SELECT ROUND(@Val,3)
SELECT ROUND(@Val,4)


--*
DECLARE @Val decimal(9,4)
SET @Val = 6983.3639

SELECT ROUND(@Val,0)
SELECT ROUND(@Val,-1)
SELECT ROUND(@Val,-2)
SELECT ROUND(@Val,-3)
SELECT ROUND(@Val,-4)


--*
DECLARE @Val decimal(9,4)
SET @Val = 6983.3639

SELECT ROUND(@Val,0,1)
SELECT ROUND(@Val,1,1)
SELECT ROUND(@Val,2,1)
SELECT ROUND(@Val,3,1)


--Aggregate Functions
--*
CREATE TABLE #AVG_Example (Value decimal(4,2))
go
INSERT #AVG_Example VALUES (5)
INSERT #AVG_Example VALUES (NULL)
INSERT #AVG_Example VALUES (10)

SELECT AVG(Value) FROM #AVG_Example


--*
INSERT #AVG_Example VALUES (5)

SELECT AVG(Value) FROM #AVG_Example
SELECT AVG(DISTINCT Value) FROM #AVG_Example


--*
CREATE TABLE #COUNT_Example (Value decimal(4,2))
go
INSERT #COUNT_Example VALUES (5)
INSERT #COUNT_Example VALUES (NULL)
INSERT #COUNT_Example VALUES (10)
INSERT #COUNT_Example VALUES (5)

SELECT COUNT(Value) FROM #COUNT_Example
SELECT COUNT(DISTINCT Value) FROM #COUNT_Example
SELECT COUNT(*) FROM #COUNT_Example


--*
CREATE TABLE #MAX_Example (Value decimal(4,2))
go
INSERT #MAX_Example VALUES (5)
INSERT #MAX_Example VALUES (NULL)
INSERT #MAX_Example VALUES (10)
INSERT #MAX_Example VALUES (10.01)

SELECT MAX(Value) FROM #MAX_Example


--*
CREATE TABLE #MIN_Example (Value tinyint)
go
INSERT #MIN_Example VALUES (5)
INSERT #MIN_Example VALUES (NULL)
INSERT #MIN_Example VALUES (10)
INSERT #MIN_Example VALUES (5)

SELECT MIN(Value) FROM #MIN_Example


--*
CREATE TABLE #SUM_Example (Value tinyint)
go
INSERT #SUM_Example VALUES (5)
INSERT #SUM_Example VALUES (NULL)
INSERT #SUM_Example VALUES (10)
INSERT #SUM_Example VALUES (5)

SELECT SUM(Value) FROM #SUM_Example
SELECT SUM(DISTINCT Value) FROM #SUM_Example


--SYSTEM FUNCTIONS
--*
SELECT Greeting = CASE DATEPART(hour, GETDATE())
                   WHEN 12 THEN 'Noon'
                   ELSE 'Not Noon'
                  END


--*
SELECT Greeting = CASE 
        WHEN DATEPART(hour,GETDATE()) BETWEEN 0 AND 6 THEN 'Early Morning'
        WHEN DATEPART(hour,GETDATE()) BETWEEN 7 AND 11 THEN 'Morning'
        WHEN DATEPART(hour,GETDATE()) BETWEEN 12 AND 17 THEN 'Afternoon'
        ELSE 'EVENING'
       END


--*
DECLARE @Val sql_variant
SET @Val = 7
SELECT CAST(@Val AS int)+65


--*
DECLARE @Val money
SET @Val = 34.84
PRINT @Val


--*
DECLARE @Val money
SET @Val = 34.84
PRINT CAST(@Val AS varchar(10))


--*
DECLARE @Val sql_variant
SET @Val = 7
SELECT CONVERT(int,@Val)+65


--*
SELECT GETDATE()
SELECT CONVERT(varchar(24),GETDATE())
SELECT CONVERT(varchar(24),GETDATE(),01)
SELECT CONVERT(varchar(24),GETDATE(),101)
SELECT CONVERT(varchar(24),GETDATE(),14)


--*
DECLARE @Val1 int,@Val2 int, @Val3 int
SET @Val1 = NULL
SET @Val2 = 3
SET @Val3 = NULL

SELECT COALESCE(@Val1,@Val2,@Val3)


--*
SELECT CURRENT_TIMESTAMP


--*
SELECT CURRENT_USER


--*
CREATE TABLE #DATALENGTH_EXAMPLE (Descriptor varchar(30))
go
INSERT #DATALENGTH_EXAMPLE VALUES ('Sammy')
INSERT #DATALENGTH_EXAMPLE VALUES ('Mark')
INSERT #DATALENGTH_EXAMPLE VALUES ('Bo')

SELECT DATALENGTH(Descriptor), Descriptor
FROM #DATALENGTH_EXAMPLE


--*
SELECT *
FROM master..sysmessages
ORDER BY severity


--*
USE Northwind
go
DECLARE @ErrNumber smallint
DELETE Customers
SET @ErrNumber = @@ERROR

IF @ErrNumber <> 0
   PRINT @ErrNumber


--*
CREATE TABLE #IDENTITY_Example (Value smallint IDENTITY, Descriptor varchar(20))
go
INSERT #IDENTITY_Example VALUES ('Piazza')
SELECT @@IDENTITY


--*
USE Northwind
SELECT IDENTITY(int) AS Customers_UniqueID,* 
INTO #Customers
FROM Customers

SELECT Customers_UniqueID, 
       CustomerID 
FROM #Customers


--*
DECLARE @Val char(8)
SET @Val = '99/00/00'
SELECT ISDATE(@Val)


--*
DECLARE @Val char(8)
SET @Val = '01/01/00'
SELECT ISDATE(@Val)


--*
DECLARE @Val char(8)
SET @Val = '5/1/2000'
SELECT ISDATE(@Val)


--*
DECLARE @Val char(8)
SET @Val = 'May 1 2000'
SELECT ISDATE(@Val)


--*
CREATE TABLE #ISNULL_Example (Price smallmoney)
go
INSERT #ISNULL_Example VALUES (5.00)
INSERT #ISNULL_Example VALUES (NULL)
INSERT #ISNULL_Example VALUES (5.00)
INSERT #ISNULL_Example VALUES (NULL)

SELECT ISNULL(Price, 0)
FROM #ISNULL_Example

SELECT AVG(Price)
FROM #ISNULL_Example

SELECT AVG(ISNULL(Price, 0))
FROM #ISNULL_Example


--*Invalid Value
DECLARE @Val varchar(10)
SET @Val = 'tt'
SELECT ISNUMERIC(@Val)


--*Valid Value
DECLARE @Val varchar(10)
SET @Val = 100
SELECT ISNUMERIC(@Val)


--*
CREATE TABLE #NEWID_Example (Value uniqueidentifier)
go
INSERT #NEWID_Example SELECT NEWID()
SELECT Value FROM #NEWID_Example


--*
CREATE TABLE #ROWCOUNT_Example (Value smallint)
go
INSERT #ROWCOUNT_Example VALUES (5)
INSERT #ROWCOUNT_Example VALUES (10)
INSERT #ROWCOUNT_Example VALUES (15)

DELETE #ROWCOUNT_Example WHERE Value <= 10
SELECT @@ROWCOUNT

--------------------------------------*End of Ch 06 - T-SQL Built-In Functions