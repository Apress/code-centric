--------------------------------------*Ch 2 - Data Types
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--*
DECLARE @var1 sql_variant, @var2 sql_variant
SET @var1 = 65000
SET @var2 = 34
SELECT CAST(@var1 AS int) + CAST(@var2 AS tinyint)


--*
DECLARE @var1 sql_variant, @var2 sql_variant
SET @var1 = 65000
SET @var2 = 34
SELECT CAST(@var1 AS int) + @var2


--*
USE tempdb
go
EXEC sp_addtype phone, 'CHAR(10)', 'NOT NULL'

--------------------------------------*End of Ch 2 - Data Types