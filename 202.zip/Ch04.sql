--------------------------------------* Ch 04 - DML - SELECT, JOINS and Control-of-Flow
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/


--Before You Get Started
--*
USE Northwind
go
SELECT City, COUNT(City) AS CityCount
FROM  Customers
GROUP BY City


---Simple SELECT
--*
USE Northwind
go
SELECT Country
FROM  Customers


--*
USE Northwind
go
SELECT DISTINCT Country
FROM  Customers


--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers


--*
USE Northwind
go
SELECT CompanyName+'-->'+Country
FROM Customers


--ORDER BY
--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers
ORDER BY CompanyName


--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers
ORDER BY Country DESC


--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers
ORDER BY Country, CompanyName DESC


--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers
ORDER BY 2, 1 DESC


--WHERE
--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers
WHERE Country = 'Germany'


--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers
WHERE Country = 'Germany'
ORDER BY CompanyName


--*
USE Northwind
go
SELECT CompanyName, Country, City
FROM Customers
WHERE Country = 'UK' AND
      City = 'London'


--*
USE Northwind
go
SELECT CompanyName, Country, City
FROM Customers
WHERE Country = 'UK' AND
      City <> 'London'


--*
USE Northwind
go
SELECT COUNT(*) 
FROM Orders
WHERE OrderDate > '1/1/97'


--*
USE Northwind
go
SELECT COUNT(*) 
FROM Orders
WHERE OrderDate > '1/1/97 14:00:00'


--*
USE Northwind
go
SELECT COUNT(*) 
FROM Orders
WHERE OrderDate > '1/1/97' AND
      OrderDate < '1/31/97'


--*
USE Northwind
go
SELECT COUNT(*) 
FROM Orders
WHERE OrderDate > '1/1/97' AND
      OrderDate < '1/31/97'AND
      ShipCountry = 'France'


--INTO
--*
USE Northwind
go
SELECT CompanyName, Country
INTO Customers_NameAndCountry
FROM Customers

SELECT CompanyName, Country
FROM Customers_NameAndCountry


--*
USE Northwind
go
SELECT CompanyName, Country
INTO #Customers_NameAndCountry
FROM Customers

SELECT CompanyName, Country
FROM #Customers_NameAndCountry


--GROUP BY
--*
USE Northwind
go
SELECT ShipCountry 
FROM Orders
GROUP BY ShipCountry


--*
USE Northwind
go
SELECT ShipCountry,
       COUNT(ShipCountry)
FROM Orders
GROUP BY ShipCountry


--*
USE Northwind
go
SELECT ShipCountry,
       ShipCity,
       COUNT(ShipCountry)
FROM Orders
GROUP BY ShipCountry


--*
USE Northwind
go
SELECT ShipCountry,
       ShipCity,
       COUNT(ShipCountry)
FROM Orders
GROUP BY ShipCountry, ShipCity


--HAVING
--*
USE Northwind
go
SELECT ShipCountry,
       ShipCity,
       COUNT(ShipCountry)
FROM Orders
GROUP BY ShipCountry, ShipCity
HAVING COUNT(ShipCountry) > 5


--TOP N
--*
USE Northwind
go
SELECT TOP 10 CustomerID, 
              COUNT(CustomerID)
FROM Orders
GROUP BY CustomerID
ORDER BY COUNT(CustomerID) DESC


--*
USE Northwind
go
SELECT TOP 10 WITH TIES CustomerID, 
              COUNT(CustomerID)
FROM Orders
GROUP BY CustomerID
ORDER BY COUNT(CustomerID) DESC


--*
USE Northwind
go
SELECT TOP 10 WITH TIES CustomerID, 
              COUNT(CustomerID)
FROM Orders
GROUP BY CustomerID
ORDER BY COUNT(CustomerID) ASC


--UNION
--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers_NameAndCountry
UNION
SELECT CompanyName, Country
FROM Customers


--*
USE Northwind
go
SELECT CompanyName, Country
FROM Customers_NameAndCountry
UNION ALL
SELECT CompanyName, Country
FROM Customers


--*
USE tempdb
go
CREATE TABLE Q1_2000
(
 Region varchar(5) NOT NULL,
 CustomerID varchar(10) NOT NULL,
 SalesAmount money NOT NULL,
 SalesDate smalldatetime NOT NULL
)
CREATE TABLE Q2_2000
(
 Region varchar(5) NOT NULL,
 CustomerID varchar(10) NOT NULL,
 SalesAmount money NOT NULL,
 SalesDate smalldatetime NOT NULL
)
go

--*
SELECT Region,
       CustomerID,
       SalesAmount,
       SalesDate,
       'Q12000'
FROM Q1_2000
UNION
SELECT Region,
       CustomerID,
       SalesAmount,
       SalesDate,
       'Q22000'
FROM Q2_2000


--*
SELECT Region,
       CustomerID,
       SalesAmount,
       SalesDate,
       'Q12000'
FROM Q1_2000
UNION
SELECT Region,
       CustomerID,
       SalesAmount,
       SalesDate,
       'Q22000'
FROM Q2_2000
UNION
SELECT Region,
       CustomerID,
       SalesAmount,
       SalesDate,
       'Q32000'
FROM Q3_2000


--*
USE Northwind
go
SELECT CompanyName 
FROM Customers
UNION
SELECT Freight 
FROM Orders


--*
USE Northwind
go
SELECT CompanyName, 99999 AS Freight
FROM Customers
UNION
SELECT 'ColumnFiller', Freight 
FROM Orders
ORDER BY Freight


--Logical Operators
--*
USE Northwind
go
SELECT CompanyName,
       City,
       Country
FROM Customers
WHERE City = 'London' AND
      Country = 'UK' OR
      City = 'Madrid'


--*
USE Northwind
go
SELECT CompanyName,
       City
FROM Customers
WHERE City IN ('London','Madrid','Seattle')


--*
USE Northwind
go
SELECT CompanyName,
       City
FROM Customers
WHERE City NOT IN ('London','Madrid','Seattle')


--*
USE Northwind
go
SELECT CompanyName
FROM Customers
WHERE CompanyName LIKE 'Ch%'


--*
USE Northwind
go
SELECT CompanyName
FROM Customers
WHERE CompanyName LIKE '%eno%'


--*
USE Northwind
go
SELECT CompanyName
FROM Customers
WHERE CompanyName LIKE 'A_[m-z]%'


--*
USE Northwind
go
SELECT COUNT(*) 
FROM Orders
WHERE OrderDate BETWEEN '1/1/97' AND '1/31/97'


--Table & Column Aliasing
--*
USE Northwind
go
SELECT a.CompanyName
FROM Customers AS a
WHERE a.CompanyName LIKE 'M%'


--*
USE Northwind
go
SELECT a.CompanyName
FROM Customers a
WHERE a.CompanyName LIKE 'M%'


---*
USE Northwind
go
SELECT TOP 10 CustomerID, 
              COUNT(CustomerID) AS OrderCount
FROM Orders
GROUP BY CustomerID
ORDER BY COUNT(CustomerID) DESC


--Joins
--*
USE Northwind
go
SELECT CompanyName, ShipName
FROM Customers, Orders


--*
USE Northwind
go
SELECT Customers.CompanyName, 
                Orders.ShipName
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
ORDER BY Customers.CompanyName


--*
USE Northwind
go
SELECT DISTINCT Customers.CompanyName, 
                Orders.ShipName
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
ORDER BY Customers.CompanyName


--*
USE Northwind
go
SELECT DISTINCT Customers.CompanyName, 
                Orders.ShipName
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
WHERE Customers.CompanyName <> Orders.ShipName
ORDER BY Customers.CompanyName


--*
USE Northwind
go
SELECT DISTINCT a.CompanyName, 
                b.ShipName
FROM Customers a, Orders b
WHERE a.CustomerID = b.CustomerID AND
      a.CompanyName <> b.ShipName
ORDER BY a.CompanyName


--*
USE Northwind
go
SELECT a.CompanyName, b.OrderDate
FROM Customers a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
ORDER BY a.CompanyName, b.OrderDate

 
--*
USE Northwind
go
SELECT a.CompanyName
FROM Customers a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
GROUP BY a.CompanyName
HAVING COUNT(a.CompanyName) = 1
ORDER BY a.CompanyName


--*
USE Northwind
go
SELECT a.CompanyName, 
       COUNT(a.CompanyName) AS OrderCount
FROM Customers a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
GROUP BY a.CompanyName
ORDER BY COUNT(a.CompanyName) DESC


--*
USE Northwind
go
SELECT a.CompanyName, 
       COUNT(a.CompanyName) AS OrderCount
FROM Customers a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
WHERE b.OrderDate BETWEEN '1/1/98' AND '12/31/98'
GROUP BY a.CompanyName
ORDER BY COUNT(a.CompanyName) DESC


--Three or more tables
--*
USE Northwind
go
SELECT a.CompanyName, 
       b.OrderDate, 
       c.LastName
FROM Customers a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
INNER JOIN Employees c ON b.EmployeeID = c.EmployeeID
ORDER BY a.CompanyName, c.LastName


--*
USE Northwind
go
SELECT a.CompanyName, 
       c.LastName, 
       COUNT(c.LastName) AS OrderCount
FROM Customers AS a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
INNER JOIN Employees c ON b.EmployeeID = c.EmployeeID
GROUP BY a.CompanyName, c.LastName


--*
USE Northwind
go
SELECT a.CompanyName, 
       b.OrderDate, 
       d.ProductName
FROM Customers a
INNER JOIN Orders b ON a.CustomerID = b.CustomerID
INNER JOIN [Order Details] c ON b.OrderID = c.OrderID
INNER JOIN Products d ON c.ProductID = d.ProductID
GROUP BY a.CompanyName, b.OrderDate, d.ProductName



--Self Joins
--*
USE Northwind
go
SELECT a.LastName AS Employee, 
      b.LastName AS Supervisor
FROM Employees a
INNER JOIN Employees b
ON a.ReportsTo = b.EmployeeID


--Outer Join
--*
USE Northwind
go
SELECT a.CompanyName, 
       COUNT(b.OrderDate) AS OrderCount
FROM Customers a
LEFT JOIN Orders b ON a.CustomerID = b.CustomerID
GROUP BY a.CompanyName


--*
USE Northwind
go
SELECT b.CompanyName, 
       COUNT(a.OrderDate) AS OrderCount
FROM  Orders a
RIGHT JOIN Customers b ON a.CustomerID = b.CustomerID
GROUP BY b.CompanyName


--*
USE Northwind
go
SELECT a.CompanyName, b.OrderDate, c.OrderID
FROM Customers a
LEFT JOIN Orders b ON a.CustomerID = b.CustomerID
LEFT JOIN [Order Details] c ON b.OrderID = c.OrderID
WHERE b.OrderDate IS NOT NULL AND
      c.OrderID IS NULL 


--*
USE Northwind
go
INSERT CustomerDemographics (CustomerTypeID,CustomerDesc) VALUES ('A1','Annual revenue less than $100,000')


--*
USE Northwind
go
INSERT CustomerCustomerDemo (CustomerID, CustomerTypeID) VALUES ('PARIS','A1')
INSERT CustomerCustomerDemo (CustomerID, CustomerTypeID) VALUES ('FISSA','A1')


--*
USE Northwind
go
SELECT a.CompanyName, d.CustomerDesc
FROM Customers a
LEFT JOIN Orders b ON a.CustomerID = b.CustomerID
INNER JOIN CustomerCustomerDemo c ON a.CustomerID = c.CustomerID
INNER JOIN CustomerDemographics d ON c.CustomerTypeID = d.CustomerTypeID
WHERE b.OrderDate IS NULL


--Subqueries
--*
USE Northwind
go
SELECT ProductName, CategoryID
FROM Products
WHERE UnitPrice > (SELECT AVG(UnitPrice)
                   FROM Products)


--*
USE Northwind
go
SELECT CompanyName
FROM Customers
WHERE CustomerID NOT IN (SELECT CustomerID
                         FROM Orders)


--*
USE Northwind
go
SELECT UnitPrice,
       (SELECT MIN(UnitPrice) FROM Products) AS MinPrice,
       UnitPrice - (SELECT MIN(UnitPrice) FROM Products) AS MinDifference,
       (SELECT AVG(UnitPrice) FROM Products) AS AvgPrice,
       UnitPrice - (SELECT AVG(UnitPrice) FROM Products) AS AvgDifference,
       (SELECT MAX(UnitPrice) FROM Products) AS MaxPrice,
       UnitPrice - (SELECT MAX(UnitPrice) FROM Products) AS MaxDifference
FROM Products
ORDER BY MinDifference


--Correlated Subqueries
--*
USE Northwind
go
SELECT CompanyName, 
       (SELECT MAX(OrderDate) 
        FROM Orders 
        WHERE Customers.CustomerID = Orders.CustomerID) AS LastOrder
FROM Customers
ORDER BY CompanyName


--*
USE Northwind
go
SELECT CompanyName, 
       MAX(OrderDate) AS LastOrder
FROM Customers
INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
GROUP BY CompanyName
ORDER BY CompanyName


--*
USE Northwind
go
SELECT a.CompanyName
FROM Customers a
WHERE NOT EXISTS (SELECT CompanyName
                  FROM Orders b
                  WHERE a.CustomerID = b.CustomerID)



--Derived Tables
--*
USE Northwind
go
SELECT * 
FROM (SELECT CustomerID,
             CompanyName 
      FROM Customers) AS DerivedTable


--*
USE Northwind
go
SELECT TOP 5 WITH TIES *
FROM (SELECT CompanyName, 
             COUNT(CompanyName) AS OrderCount
      FROM Customers
      INNER JOIN Orders ON Customers.CustomerID = Orders.CustomerID
      GROUP BY CompanyName) AS DerivedTable
ORDER BY OrderCount DESC



--Cross Database
--*
USE Northwind
go
SELECT * 
INTO pubs..Orders
FROM Northwind..Orders


--*
USE Northwind
go
SELECT DISTINCT a.CompanyName, b.ShipName
FROM Customers a
INNER JOIN pubs..Orders b ON a.CustomerID = b.CustomerID
WHERE a.CompanyName <> b.ShipName


--Control-of-Flow
--*
USE tempdb
go
CREATE TABLE #Flow 
(
 Flo_UniqueID int IDENTITY, 
 Flo_Name varchar(10)
)
go
INSERT #Flow (Flo_Name) VALUES ('While')

SELECT * FROM #Flow


--*
USE tempdb
go
INSERT #Flow (Flo_Name) VALUES ('While')
IF @@IDENTITY > 5
 BEGIN
  SELECT * 
  FROM #Flow
 END


--*
USE tempdb
go
INSERT #Flow (Flo_Name) VALUES ('While')
IF @@IDENTITY > 5
 BEGIN
  SELECT * 
  FROM #Flow
  
  SELECT COUNT(*) AS RecordCount
  FROM #Flow 
 END


--*
USE tempdb
go
INSERT #Flow (Flo_Name) VALUES ('While')
IF @@IDENTITY < 5
 BEGIN
  SELECT * 
  FROM #Flow
  
  SELECT COUNT(*) AS RecordCount 
  FROM #Flow 
 END
ELSE
 BEGIN
  SELECT GETDATE()
 END


--*
USE tempdb
go
INSERT #Flow (Flo_Name) VALUES ('While')
IF (SELECT COUNT(*) FROM #Flow) > 5
  SELECT * 
  FROM #Flow


--*
USE tempdb
go
INSERT #Flow (Flo_Name) VALUES ('While')
IF (SELECT COUNT(*) AS RecordCount FROM #Flow) < 5
  SELECT * 
  FROM #Flow
  
  SELECT GETDATE()


--*
DECLARE @Counter smallint
SET @Counter = 1
WHILE @Counter < 5
 BEGIN
  PRINT @Counter
  SET @Counter = @Counter + 1
 END 
PRINT 'Loop Complete'


--*
USE tempdb
go
CREATE TABLE #Counter (Cou_Value tinyint)
go

DECLARE @Counter smallint
SET @Counter = 1

WHILE @Counter < 10
 BEGIN
   IF @Counter = 5
    BEGIN  
     INSERT #Counter (Cou_Value) VALUES (@Counter)
     BREAK
    END
   ELSE
    BEGIN
     SET @Counter = @Counter + 1
     CONTINUE
    END
 END 

SELECT Cou_Value FROM #Counter


--*
DECLARE @OuterCounter smallint,
        @InnerCounter smallint
SET @OuterCounter = 0
SET @InnerCounter = 1

WHILE @OuterCounter < 2
 BEGIN
 PRINT '** Outer Loop **'

  WHILE @InnerCounter < 5
   BEGIN
    PRINT 'Inner Loop' 
    SET @InnerCounter = @InnerCounter + 1
   END 
   
   SET @InnerCounter = 1
   SET @OuterCounter = @OuterCounter + 1
 END 


--*
USE tempdb
go
CREATE PROCEDURE ps_Orders_SELECT
AS
DECLARE @ErrorValue smallint

SELECT COUNT(*)
FROM Northwind..Orders

SET @ErrorValue = @@Error

RETURN @ErrorValue
go

DECLARE @ReturnValue smallint
EXEC @ReturnValue = ps_Orders_SELECT
PRINT 'Return Value = ' + CAST(@ReturnValue AS varchar(5))


--*
WAITFOR DELAY '00:00:10'
SELECT GETDATE()


--*
WAITFOR TIME '23:59:59'
SELECT GETDATE()


--*
DECLARE @Counter smallint
SET @Counter = 1
WHILE @Counter < 5
 BEGIN
  IF @Counter = 3
   BEGIN
    GOTO EndOfCode 
   END
  SET @Counter = @Counter+1
 END 

PRINT 'Loop Complete'

EndOfCode:
PRINT 'Skipped PRINT statement'


--Cursors
--*
USE Northwind
go
DECLARE crs_TableCount INSENSITIVE CURSOR
FOR SELECT name
    FROM sysobjects
    WHERE xtype = 'U'

OPEN crs_TableCount

DECLARE @TableName varchar(40)
DECLARE @TableCount smallint

WHILE @@FETCH_STATUS <> -1
 BEGIN
  FETCH NEXT FROM crs_TableCount INTO @TableName
  PRINT @TableName
  EXEC('SELECT COUNT(*) FROM ['+ @TableName+']')
 END

CLOSE crs_TableCount
DEALLOCATE crs_TableCount

--------------------------------------*End of Ch 04 - DML - SELECT, JOINS and Control-of-Flow

