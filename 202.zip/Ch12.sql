--------------------------------------*Ch 12 - Triggers
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--CREATE TRIGGER
--*
USE tempdb
go
CREATE TABLE Orders
(
 Ord_UniqueID smallint IDENTITY PRIMARY KEY,
 Ord_Name varchar(30) NOT NULL,
 Ord_Priority tinyint NOT NULL,
 Ord_Date smalldatetime DEFAULT GETDATE()
)
go 
CREATE TABLE HotOrders
(
 HotOrd_UniqueID smallint IDENTITY NOT NULL,
 Ord_UniqueID smallint FOREIGN KEY REFERENCES Orders(Ord_UniqueID) NOT NULL
)
 

--*
USE tempdb
go
CREATE TRIGGER tr_Orders_INSERT_HotOrders
ON Orders
AFTER INSERT
AS
--Determine if hot orders have been entered
IF EXISTS (SELECT * FROM inserted WHERE Ord_Priority > 6)
 BEGIN
  --HotOrders code
  INSERT HotOrders (Ord_UniqueID) 
  SELECT Ord_UniqueID FROM inserted
  WHERE Ord_Priority > 6

  /*
  --Email code
  DECLARE  @Count smallint,
           @EmailMessage varchar(100)
  --Determine number of "hot" orders
  SELECT @Count = COUNT(Ord_UniqueID) 
  FROM inserted
  WHERE Ord_Priority > 6
  --Build message
  SELECT @EmailMessage = CAST(@COUNT AS varchar(3))+ ' Hot Order(s) Entered'
  --Send email
  EXEC master..xp_sendmail @recipients = 'garth@SQLBook.com',
                           @message = @EmailMessage,
                           @subject = 'Hot Orders Entered'
  */
 END


--*  
USE tempdb
go
INSERT Orders (Ord_Name, Ord_Priority) VALUES ('First Order',6)
INSERT Orders (Ord_Name, Ord_Priority) VALUES ('Second Order',9)
INSERT Orders (Ord_Name, Ord_Priority) VALUES ('Third Order',10)

SELECT a.Ord_Name, b.*  
FROM Orders a
JOIN HotOrders b ON a.Ord_UniqueID =  b.Ord_UniqueID


--*
INSERT Orders (Ord_Name, Ord_Priority)
SELECT Ord_Name, Ord_Priority
FROM Orders
WHERE Ord_Priority > 6

SELECT a.Ord_Name, b.*  
FROM Orders a
JOIN HotOrders b ON a.Ord_UniqueID =  b.Ord_UniqueID


--*
USE tempdb
go
DROP TRIGGER tr_Orders_INSERT_HotOrders
go
CREATE TRIGGER tr_Orders_INSERT_HotOrdersSingleRow
ON Orders
AFTER INSERT
AS
--Determine if hot order has been entered
IF (SELECT COUNT(*) FROM inserted WHERE Ord_Priority > 6) = 1
 BEGIN
  --HotOrders code
  INSERT HotOrders (Ord_UniqueID) 
  SELECT Ord_UniqueID FROM inserted


  /*
  --Email code
  --Build message
  SELECT @EmailMessage = CAST(@COUNT AS varchar(3))+ ' Hot Order(s) Entered'
  --Send email
  EXEC master..xp_sendmail @recipients = 'garth@SQLBook.com',
                           @subject = 'Hot Order Entered'
  */
 END


--*
USE tempdb
go
INSERT Orders (Ord_Name, Ord_Priority)
SELECT Ord_Name, Ord_Priority
FROM Orders
WHERE Ord_Priority > 6

SELECT a.Ord_Name, b.*  
FROM Orders a
JOIN HotOrders b ON a.Ord_UniqueID =  b.Ord_UniqueID


--*
USE tempdb
go
DROP TRIGGER tr_Orders_INSERT_HotOrdersSingleRow
go
CREATE TRIGGER tr_Orders_INSERT_HotOrders
ON Orders
AFTER INSERT
AS
--Determine if hot orders have been entered
IF EXISTS (SELECT * FROM inserted WHERE Ord_Priority > 6)
 BEGIN
  --HotOrders code
  INSERT HotOrders (Ord_UniqueID) 
  SELECT Ord_UniqueID FROM inserted
  WHERE Ord_Priority > 6

  /*
  --Email code
  DECLARE  @Count smallint,
           @EmailMessage varchar(100)
  --Determine number of "hot" orders
  SELECT @Count = COUNT(Ord_UniqueID) 
  FROM inserted
  WHERE Ord_Priority > 6
  --Build message
  SELECT @EmailMessage = CAST(@COUNT AS varchar(3))+ ' Hot Order(s) Entered'
  --Send email
  EXEC master..xp_sendmail @recipients = 'garth@SQLBook.com',
                           @message = @EmailMessage,
                           @subject = 'Hot Orders Entered'
  */
 END


--*
USE tempdb
go
CREATE TRIGGER tr_Orders_UPDATE_HotOrders
ON Orders
AFTER UPDATE
AS

--Make sure priority was changed
IF NOT UPDATE(Ord_Priority)
 BEGIN
  RETURN
 END

--Determine if priority was changed to greater than 6
IF EXISTS (SELECT * 
           FROM inserted a
           JOIN deleted b ON a.Ord_UniqueID = b.Ord_UniqueID
           WHERE b.Ord_Priority <= 6 AND
                 a.Ord_Priority > 6)
 BEGIN

  --HotOrders code
  INSERT HotOrders (Ord_UniqueID) 
  SELECT a.Ord_UniqueID 
  FROM inserted a
  JOIN deleted b ON a.Ord_UniqueID = b.Ord_UniqueID
  WHERE b.Ord_Priority <= 6 AND
        a.Ord_Priority > 6
  /*
  --Email code
  DECLARE  @Count smallint,
           @EmailMessage varchar(100)
  --Determine number of "hot" orders
  SELECT @Count = COUNT(a.Ord_UniqueID) 
  FROM inserted a
  JOIN deleted b ON a.Ord_UniqueID = b.Ord_UniqueID
  WHERE b.Ord_Priority <= 6 AND
        a.Ord_Priority > 6
  --Build message
  SELECT @EmailMessage = CAST(@COUNT AS varchar(3))+ ' Order(s) was Updated to Hot Status'
  --Send email
  EXEC master..xp_sendmail @recipients = 'garth@SQLBook.com',
                           @message = @EmailMessage,
                           @subject = 'Order Updated to Hot Status'
  */
 END


--*
USE tempdb
go
SELECT a.Ord_Name, b.*  
FROM Orders a
JOIN HotOrders b ON a.Ord_UniqueID =  b.Ord_UniqueID


--*
USE tempdb
go
UPDATE Orders
SET Ord_Priority = 9
WHERE Ord_UniqueID = 1

SELECT a.Ord_Name, b.*  
FROM Orders a
JOIN HotOrders b ON a.Ord_UniqueID =  b.Ord_UniqueID


--ALTER Trigger
--*
USE tempdb
go
sp_helptext 'tr_Orders_INSERT_HotOrders'


--*
USE tempdb
go
ALTER TRIGGER tr_Orders_INSERT_HotOrders
ON Orders
AFTER INSERT
AS
--Determine if hot orders have been entered
IF EXISTS (SELECT * FROM inserted WHERE Ord_Priority >= 8)
 BEGIN

  --HotOrders code
  INSERT HotOrders (Ord_UniqueID) 
  SELECT Ord_UniqueID FROM inserted
  WHERE Ord_Priority >= 8

  /*
  --Email code
  DECLARE  @Count smallint,
           @EmailMessage varchar(100)
  --Determine number of "hot" orders
  SELECT @Count = COUNT(Ord_UniqueID) 
  FROM inserted
  WHERE Ord_Priority >= 8
  --Build message
  SELECT @EmailMessage = CAST(@COUNT AS varchar(3))+ ' Hot Order(s) Entered'
  --Send email
  EXEC master..xp_sendmail @recipients = 'garth@SQLBook.com',
                           @message = @EmailMessage,
                           @subject = 'Hot Orders Entered'
  */
 END


--*
USE tempdb
go
DROP TRIGGER tr_Orders_HotOrders

--------------------------------------*End of Ch 12 - Triggers