--------------------------------------*Ch 9 - System Stored Procedures
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--System Tables
--*
SELECT * FROM sysaltfiles

--*
SELECT * FROM syscacheobjects

--*
SELECT * FROM syscharsets

--*
SELECT * FROM sysconfigures

--*
SELECT * FROM syscurconfigs

--*
SELECT * FROM sysdatabases

--*
SELECT * FROM sysdevices

--*
SELECT * FROM syslanguages

--*
SELECT * FROM syslockinfo

--*
SELECT * FROM syslogins

--*
SELECT * FROM sysmessages

--*
SELECT * FROM sysoledbusers

--*
SELECT * FROM sysperfinfo

--*
SELECT * FROM sysprocesses

--*
SELECT * FROM sysremotelogins

--*
SELECT * FROM sysservers



--All Databases
--*
SELECT * FROM syscolumns

--*
SELECT * FROM syscomments

--*
SELECT * FROM sysconstraints

--*
SELECT * FROM sysdepends

--*
SELECT * FROM sysfilegroups

--*
SELECT * FROM sysfiles

--*
SELECT * FROM sysfulltextcatalogs

--*
SELECT * FROM sysindexes

--*
SELECT * FROM sysindexkeys

--*
SELECT * FROM sysmembers

--*
SELECT * FROM sysobjects

--*
SELECT * FROM syspermissions

--*
SELECT * FROM sysprotects

--*
SELECT * FROM sysreferences

--*
SELECT * FROM systypes

--*
SELECT * FROM sysusers


--msdb tables
--*
USE msdb
go
SELECT * FROM sysalerts

--*
USE msdb
go
SELECT * FROM syscategories

--*
USE msdb
go
SELECT * FROM sysdownloadlist

--*
USE msdb
go
SELECT * FROM sysjobhistory

--*
USE msdb
go
SELECT * FROM sysjobs

--*
USE msdb
go
SELECT * FROM sysjobschedules

--*
USE msdb
go
SELECT * FROM sysjobservers

--*
USE msdb
go
SELECT * FROM sysjobsteps

--*
USE msdb
go
SELECT * FROM sysnotifications

--*
USE msdb
go
SELECT * FROM sysoperators

--*
USE msdb
go
SELECT * FROM systargetservergroupmembers

--*
USE msdb
go
SELECT * FROM systargetservergroups

--*
USE msdb
go
SELECT * FROM systargetservers

--*
USE msdb
go
SELECT * FROM systaskids

--*
USE msdb
go
SELECT * FROM backupfile

--*
USE msdb
go
SELECT * FROM backupmediafamily

--*
USE msdb
goSELECT * FROM backupmediaset

--*
USE msdb
go
SELECT * FROM backupset

--*
USE msdb
go
SELECT * FROM restorefile

--*
USE msdb
go
SELECT * FROM restorefilegroup

--*
USE msdb
go
SELECT * FROM  restorehistory


--What are System Stored Procedures
--*
USE master
go
EXEC sp_helptext 'sp_databases'


--*
USE master
go
EXEC sp_databases


--*
USE master
go
SELECT COUNT(*) AS spCount
FROM sysobjects
WHERE name like 'sp%'



--Catalog Procedrues
--*
EXEC sp_databases


--*
USE Northwind
go
EXEC sp_tables


--*
USE Northwind
go
EXEC sp_tables @table_type = "'view'"


--*
USE Northwind
go
EXEC sp_tables @type = "'VIEW'"


--*
USE Northwind
go
EXEC sp_table_privileges 'Orders'


--*
USE Northwind
go
EXEC sp_columns 'Orders'


--*
USE Northwind
go
EXEC sp_column_privileges 'Orders'


--*
USE Northwind
go
EXEC sp_pkeys 'Orders'


--*
USE Northwind
go
EXEC sp_fkeys 'Orders' 


--*
USE Northwind
go
EXEC sp_stored_procedures


--*
EXEC sp_sproc_columns 'CustOrderHist'


--*
EXEC sp_statistics 'Orders'


--Distributed Queries
--*
EXEC sp_addlinkedserver @server = 'AccessOnAce',
                        @srvproduct = 'OLE DB Provider for Jet',
                        @provider = 'Microsoft.Jet.OLEDB.4.0',  
                        @datasrc = 'C:\Program Files\Microsoft Office\Office\Samples\Northwind.mdb' 

--*
EXEC sp_addlinkedsrvlogin @rmtsrvname  = 'AccessOnAce',
                          @useself = 'false',
                          @locallogin = NULL,
                          @rmtuser = NULL,
                          @rmtpassword =  NULL

--*
SELECT CompanyName from AccessOnAce...Customers


--*
EXEC sp_droplinkedsrvlogin @rmtsrvname =  'AccessOnAce' , 
                           @locallogin = NULL


--*
EXEC sp_linkedservers


--*
EXEC sp_dropserver 'AccessOnAce'



--Security
--*
EXEC sp_addlogin @loginame =  'Sara' 


--*
EXEC sp_addlogin @loginame =  'Sara2', 
            @passwd = 'blue', 
            @defdb =  'Northwind'


--*
USE Northwind
go
EXEC sp_grantdbaccess @loginame = 'Sara2'


--*
EXEC sp_grantlogin @loginame = 'Domain\Randy'


--*
EXEC sp_helplogins


--*
EXEC sp_helpuser


--*
EXEC sp_password @old = 'blue',
                 @new = 'green', 
                 @loginame =  'Sara2'


--*
EXEC sp_validatelogins


--*
EXEC sp_revokelogin @loginame = 'Domain\Tipper'


--*
EXEC sp_revokelogin @loginame = 'Domain\Randy'


--*
USE Northwind
go
EXEC sp_revokedbaccess @name_in_db =  'Sara2'


--*
USE Northwind
go
EXEC sp_grantdbaccess @loginame = 'Sara'
go
EXEC sp_changeobjectowner @objname =  'Orders',
                          @newowner = 'Sara'
go
EXEC sp_changeobjectowner @objname =  'Sara.Orders',
                          @newowner = 'dbo'


--*
USE Northwind
go
EXEC sp_addrole @rolename =  'Auditors' 


--*
USE Northwind
go
EXEC sp_addrolemember @rolename = 'Auditors' , 
                      @membername =  'Sara' 

--*
USE Northwind
go
EXEC sp_addapprole @rolename =  'AcctApp', 
              @password =  'MoneyFunnel'

--*
EXEC sp_srvrolepermission @srvrolename = 'securityadmin'


--System
--*
USE Northwind
go
--Create variables 
DECLARE @StartDate datetime
DECLARE @SQLString nvarchar(200)
DECLARE @ParmDefinition nvarchar(100)

--Populate variables
SET @SQLString =  N'SELECT OrderID, CustomerID FROM Orders WHERE OrderDate >  = @FilterDate'
SET @ParmDefinition = N'@FilterDate datetime'
SET @StartDate = '05/05/98'

--Execut First Query
EXEC sp_executesql @SQLString, 
                   @ParmDefinition,
                   @FilterDate = @StartDate

--Change the filter date
SET @StartDate = '05/06/98'

--Execute second query
EXEC sp_executesql @SQLString, 
                   @ParmDefinition,
                   @FilterDate = @StartDate


--*
USE Northwind
go
EXEC sp_addtype @typename = State, 
           @phystype = 'char(2)', 
           @nulltype = 'Not Null'  


--*
USE Northwind
go
EXEC sp_droptype @typename = State 


--*
EXEC sp_configure


--*
EXEC sp_configure @configname =  'show advanced options',
                  @configvalue = '0'  
RECONFIGURE WITH OVERRIDE


--*
--Check existing setting
EXEC sp_dbcmptlevel @dbname = 'Northwind'

--Change to 6.5 compatibility
EXEC sp_dbcmptlevel @dbname = 'Northwind', 
                    @new_cmptlevel = '65'


--Verify change
EXEC sp_dbcmptlevel @dbname = 'Northwind'


--Change back to 2000 compatibility
EXEC sp_dbcmptlevel @dbname = 'Northwind', 
               @new_cmptlevel = '80'


--*
EXEC sp_datatype_info


--*
USE master
go
CREATE PROCEDURE dbo.StartupExample
AS
SELECT GETDATE()
go
EXEC sp_procoption @ProcName =  'StartupExample', 
              @OptionName = 'startup', 
              @OptionValue = 'true' 


--*
USE Northwind
go
EXEC sp_addtype @typename = State, 
           @phystype = 'char(2)', 
           @nulltype = 'Not Null'  
go
EXEC sp_rename @objname = 'State' , 
               @newname = 'State_New' 


--*
USE Northwind
go
EXEC sp_depends @objname =  'Orders' 


--*
--All objects in database
USE Northwind
go
EXEC sp_help


--Table
EXEC sp_help @objname = 'Orders'


--Stored Procedure
EXEC sp_help @objname = 'CustOrdersDetail'


--View
EXEC sp_help @objname = 'Invoices'


--Date type
EXEC sp_help 'int'


--*
sp_altermessage 102, 'WITH_LOG', 'true'
go
sp_altermessage 102, 'WITH_LOG', 'false'



--Web Task
--*
---------------------Maker Path is Valid Per Your Setup
USE Northwind
go
EXEC sp_makewebtask @outputfile = 'C:\MSSQL7\Binn\Customers.html',
                    @query =  'SELECT CompanyName FROM Customers',
                    @bold = 1,
                    @colheaders = 1,
                    @webpagetitle = 'Web Task Example', 
                    @procname =  'CustomerNames'


--*
USE Northwind
go
EXEC sp_makewebtask @outputfile = 'C:\MSSQL7\Binn\Customers.html',
                    @query =  'SELECT CompanyName FROM Customers',
                    @bold = 1,
                    @colheaders = 1,
                    @webpagetitle = 'Web Task Example', 
                    @procname =  'CustomerNames',
                    @whentype = 5


--*
EXEC sp_runwebtask @procname =  'CustomerNames'


--*
EXEC sp_dropwebtask @procname =  'CustomerNames'

--------------------------------------*End of Ch 9 - System Stored Procedures