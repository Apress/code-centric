--------------------------------------*Ch 05 - DML - Inserting, Updating and Deleting Data
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--INSERT
--*
USE tempdb
go
CREATE TABLE Property 
(
 Pro_UniqueID smallint IDENTITY PRIMARY KEY,
 Pro_Name varchar(30) NOT NULL,
 Pro_Type varchar(15) DEFAULT 'Strip Center'
)


--*
USE tempdb
go
INSERT Property (Pro_Name, Pro_Type) VALUES ('Braes Heights','Office Building')


--*
USE tempdb
go
SET IDENTITY_INSERT Property ON
INSERT Property (Pro_UniqueID, Pro_Name, Pro_Type) VALUES (2,'Sharpstown','Office Building')
SET IDENTITY_INSERT Property OFF


--*
USE tempdb
go
INSERT Property (Pro_Name) VALUES ('Braes Heights')


--*
USE tempdb
go
INSERT Property (Pro_Name,Pro_Type) VALUES ('Braes Heights',DEFAULT)


--*
USE tempdb
go
SELECT * 
INTO Property2 
FROM Property
WHERE Pro_Name = '99'


--*
USE tempdb
go
INSERT Property2 (Pro_Name, Pro_Type)
SELECT Pro_Name, Pro_Type
FROM Property

SELECT *
FROM Property2


--*
USE tempdb
go
CREATE TABLE CustomerOrderEmployee
(
 Customer nvarchar(40), 
 OrderID int,
 Employee nvarchar(20)
)

INSERT CustomerOrderEmployee (Customer, OrderID, Employee)
SELECT a.CompanyName, b.OrderID, c.LastName
FROM Northwind..Customers a
INNER JOIN Northwind..Orders b ON a.CustomerID = b.CustomerID
INNER JOIN Northwind..Employees c ON b.EmployeeID = c.EmployeeID

SELECT * 
FROM CustomerOrderEmployee
      

--*
USE tempdb
go
CREATE PROCEDURE ps_Customers_SELECT
AS
SELECT CompanyName 
FROM Northwind..Customers


--*
USE tempdb
go
EXEC ps_Customers_SELECT


--*
USE tempdb
go
CREATE TABLE CompanyNames (CompanyName nvarchar(40))
go

INSERT CompanyNames
EXEC ps_Customers_SELECT

SELECT *
FROM CompanyNames


--UPDATE
--*
USE tempdb
go
UPDATE Property
SET Pro_Type = 'Land'

SELECT *
FROM Property


--*
USE tempdb
go
UPDATE Property
SET Pro_Type = DEFAULT


--*
USE tempdb
go
UPDATE Property
SET Pro_Type = 'Office Building'
WHERE Pro_Name = 'Sharpstown'


--*
USE tempdb
go
UPDATE Property
SET Pro_Name = 'Sharpstown II', 
    Pro_Type = 'Office Building'
WHERE Pro_Name = 'Sharpstown'


--*
USE tempdb
go
CREATE TABLE OrdersSummary 
(
 CustomerID nchar(5),
 OrderCount int
)
go
--Populate OrdersSummary with IDs
INSERT OrdersSummary 
SELECT CustomerID, 0
FROM Northwind..Customers
go
--*Update each ID with summary sales data
UPDATE OrdersSummary
SET OrderCount = OrderCount + (SELECT COUNT(OrderID)
                                FROM Northwind..Orders AS a
                                WHERE OrdersSummary.CustomerID = a.CustomerID AND
                                      OrderDate BETWEEN '7/1/96' AND '7/31/96')

SELECT *
FROM OrdersSummary
ORDER BY OrderCount DESC,
         CustomerID


--*
UPDATE OrdersSummary
SET OrderCount = OrderCount + (SELECT COUNT(OrderID)
                                FROM Northwind..Orders AS a
                                WHERE OrdersSummary.CustomerID = a.CustomerID AND
                                      OrderDate BETWEEN '8/1/96' AND '8/31/96')

SELECT *
FROM OrdersSummary
ORDER BY OrderCount DESC,
         CustomerID


--Deleting Date
--*
USE tempdb
go
DELETE OrdersSummary 
WHERE CustomerID = 'ALFKI'


--*
USE tempdb
go
DELETE OrdersSummary 
WHERE  OrderCount = 2 AND
       SUBSTRING(CustomerID,1,1) = 'T'


--*
USE tempdb
go
DELETE OrdersSummary


--*
USE Northwind
go
DELETE Products
FROM Products a
INNER JOIN Suppliers b ON a.SupplierID = b.SupplierID AND 
                          b.CompanyName = 'Pavlova, Ltd.'

--------------------------------------*End Of Ch 05 - DML - Inserting, Updating and Deleting Data