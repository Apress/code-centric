--------------------------------------*Ch 07 - User-Defined Functions
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--CREATE FUNCTION
--*
USE tempdb
go
CREATE FUNCTION fx_SumTwoValues
(
 @Val1 int,
 @Val2 int
)
RETURNS int
AS
BEGIN
   RETURN (@Val1+@Val2)
END


--*
SELECT dbo.fx_SumTwoValues(1,2) AS SumOfTwoValues


--*
SELECT dbo.fx_SumTwoValues(1.98,2.78) AS SumOfTwoValues


--*
SELECT dbo.fx_SumTwoValues('7','7') AS SumOfTwoValues


--*
SELECT dbo.fx_SumTwoValues('Y','7') AS SumOfTwoValues


--*
CREATE FUNCTION fx_SumTwoValues2
(
 @Val1 int,
 @Val2 int
)
RETURNS int
AS
BEGIN
 WHILE @Val1 < 100
  BEGIN
   SET @Val1 = @Val1 + 1
  END  
  RETURN (@Val1+@Val2)
END
go
SELECT dbo.fx_SumTwoValues2(1,7) AS SumOfTwoValues


--*
USE Northwind
go
CREATE FUNCTION fx_Customers_ByCity
(
 @City nvarchar(15)
)
RETURNS table
AS
RETURN (
        SELECT CompanyName
        FROM Customers
        WHERE City = @City
       )
go
SELECT * FROM fx_Customers_ByCity('London')


--*
USE Northwind
go
CREATE FUNCTION fx_Customers_ByCity2
(
 @City nvarchar(15)
)
RETURNS table
AS
RETURN (
        SELECT a.CompanyName,
               b.OrderDate,
               c.FirstName+' '+c.Lastname AS EmployeeName
        FROM Customers a
        JOIN Orders b ON a.CustomerID = b.CustomerID 
        JOIN Employees c ON b.EmployeeID = c.EmployeeID
        WHERE a.City = @City
       )
go
SELECT * FROM fx_Customers_ByCity2('London')


--*
USE Northwind
go
CREATE FUNCTION fx_OrdersByDateRangeAndCount 
( 
 @OrderDateStart smalldatetime, 
 @OrderDateEnd smalldatetime,
 @OrderCount smallint
)
RETURNS @OrdersByDateRange TABLE
(
 CustomerID nchar(5),
 CompanyName nvarchar(40),
 OrderCount smallint,
 Ranking char(1)
 )
AS
BEGIN
 --Statement 1
 INSERT @OrdersByDateRange
 SELECT a.CustomerID, 
        a.CompanyName,
        COUNT(a.CustomerID) AS OrderCount,
        'B'
 FROM Customers a
 JOIN Orders b ON a.CustomerID = b.CustomerID
 WHERE OrderDate BETWEEN @OrderDateStart AND @OrderDateEnd
 GROUP BY a.CustomerID, a.CompanyName
 HAVING COUNT(a.CustomerID) > @OrderCount

 --Statement 2
 UPDATE @OrdersByDateRange
 SET Ranking = 'A'
 WHERE CustomerID IN (SELECT TOP 5 WITH TIES CustomerID
                      FROM (SELECT a.CustomerID, 
                                   COUNT(a.CustomerID) AS OrderTotal 
                            FROM  Customers a
                            JOIN Orders b ON a.CustomerID = b.CustomerID
                            GROUP BY a.CustomerID) AS DerivedTable
                      ORDER BY OrderTotal DESC)

 RETURN
END


--*
SELECT * 
FROM fx_OrdersByDateRangeAndCount ('1/1/96','1/1/97',2)
ORDER By Ranking


--*
USE Northwind
go
SELECT b.text
FROM sysobjects a
INNER JOIN syscomments b ON a.id = b.id
WHERE a.name = 'fx_OrdersByDateRangeAndCount'


--*
SELECT ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_NAME = 'fx_OrdersByDateRangeAndCount'


--*
sp_helptext 'fx_OrdersByDateRangeAndCount'



--*
DROP FUNCTION fx_OrdersByDateRangeAndCount 
go
CREATE FUNCTION fx_OrdersByDateRangeAndCount 
( 
 @OrderDateStart smalldatetime, 
 @OrderDateEnd smalldatetime,
 @OrderCount smallint
)
RETURNS @OrdersByDateRange TABLE
(
 CustomerID nchar(5),
 CompanyName nvarchar(40),
 OrderCount smallint,
 Ranking char(1)
 )
WITH ENCRYPTION
AS
BEGIN
 --Statement 1
 INSERT @OrdersByDateRange
 SELECT a.CustomerID, 
        a.CompanyName,
        COUNT(a.CustomerID) AS OrderCount,
        'B'
 FROM Customers a
 JOIN Orders b ON a.CustomerID = b.CustomerID
 WHERE OrderDate BETWEEN @OrderDateStart AND @OrderDateEnd
 GROUP BY a.CustomerID, a.CompanyName
 HAVING COUNT(a.CustomerID) > @OrderCount

 --Statement 2
 UPDATE @OrdersByDateRange
 SET Ranking = 'A'
 WHERE CustomerID IN (SELECT TOP 5 WITH TIES CustomerID
                      FROM (SELECT a.CustomerID, 
                                   COUNT(a.CustomerID) AS OrderTotal 
                            FROM  Customers a
                            JOIN Orders b ON a.CustomerID = b.CustomerID
                            GROUP BY a.CustomerID) AS DerivedTable
                      ORDER BY OrderTotal DESC)

 RETURN
END
go
SELECT ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_NAME = 'fx_OrdersByDateRangeAndCount'


--*
DROP FUNCTION fx_Customers_ByCity
go
CREATE FUNCTION fx_Customers_ByCity
(
 @City nvarchar(15)
)
RETURNS table
WITH SCHEMABINDING
AS
RETURN (
        SELECT CompanyName
        FROM dbo.Customers
        WHERE City = @City
       )
go
ALTER TABLE Customers ALTER COLUMN CompanyName nvarchar(50)


--*
CREATE FUNCTION fx_WorkDaysInDateRange
(
 @DateStart smalldatetime,
 @DateEnd smalldatetime
)
RETURNS smallint
AS
BEGIN
 DECLARE @WorkDays smallint
 SET @WorkDays = 0
 WHILE @DateStart <= @DateEnd
  BEGIN
   IF DATEPART(weekday,@DateStart) BETWEEN 2 AND 5
    BEGIN
     SET @WorkDays = @WorkDays + 1
    END
   SET @DateStart = DATEADD(day,1,@DateStart)
  END  
  RETURN @WorkDays
END
go
SELECT dbo.fx_WorkDaysInDateRange('7/1/00','7/30/00') AS WorkDays


--*
SELECT name
FROM sysobjects
WHERE type = 'P'


--*
SELECT RTRIM(name)+'-->'+type  AS ObjectAndType
FROM sysobjects 
WHERE name LIKE 'fx%'


--*
CREATE FUNCTION fx_Customers_ByOrderCount ()
RETURNS table
AS
RETURN (
        SELECT CompanyName, COUNT(a.CompanyName) AS OrderCount
        FROM Customers a
        LEFT JOIN Orders b ON a.CustomerID = b.CustomerID
        GROUP BY a.CompanyName 
       )
go
SELECT TOP 5 * 
FROM fx_Customers_ByOrderCount () 
ORDER BY OrderCount DESC


--*
CREATE FUNCTION fx_CurrentTime
AS
RETURNS datetime
AS
SELECT GETDATE()

--------------------------------------*End of Ch 07 - User-Defined Functions