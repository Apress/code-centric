--------------------------------------*Ch 11 - User-Defined Stored Procedures
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/

--*
USE tempdb
go
CREATE PROCEDURE ps_UTIL_SELECT_CurrentSystemTime
AS
SELECT GETDATE() AS CurrentSystemTime
go


--*
USE tempdb
go
EXEC ps_UTIL_SELECT_CurrentSystemTime


--*
sp_addlogin 'tiger','eagle','tempdb'
go
USE tempdb
go
sp_adduser 'tiger'


--*
USE tempdb
go
EXEC ps_UTIL_SELECT_CurrentSystemTime


--*
USE tempdb
go
GRANT EXECUTE ON ps_UTIL_SELECT_CurrentSystemTime TO tiger


--*
USE tempdb
go
CREATE PROCEDURE ps_UTIL_SELECT_CurrentSystemTime
AS
SELECT GETDATE() AS CurrentSystemTime
go


--*
GRANT CREATE PROCEDURE TO tiger


--*
USE tempdb
go
SELECT ROUTINE_NAME,
       SPECIFIC_SCHEMA
FROM INFORMATION_SCHEMA.Routines



--Alter Procedure
--*
ALTER PROCEDURE ps_UTIL_SELECT_CurrentSystemTime
AS
SELECT GETDATE() AS CurrentSystemTime, 
       CONVERT(char(8),GETDATE(),1) AS USADateFormat,
       CONVERT(char(8),GETDATE(),2) AS ANSIDateFormat
go
EXEC ps_UTIL_SELECT_CurrentSystemTime


--*
USE tempdb
go
DROP PROCEDURE ps_UTIL_SELECT_CurrentSystemTime


--*Stored Procedure Debugger
--*
USE tempdb
go
CREATE PROCEDURE ps_LoopingExample
@MaxValue smallint = 10
AS
DECLARE @Counter smallint
SET @Counter = 1

WHILE @Counter < @MaxValue
 BEGIN
  PRINT CAST(@Counter AS varchar(5))
  SET @Counter = @Counter + 1
 END 
go
EXEC ps_LoopingExample @MaxValue=11


--Managing Procedures

--*Recreate procedure
CREATE PROCEDURE ps_UTIL_SELECT_CurrentSystemTime
AS
SELECT GETDATE() AS CurrentSystemTime


--*
sp_addextendedproperty @name = 'Description_2', 
                       @value = 'Returns current system time',
                       @level0type = 'user', 
                       @level0name =  'dbo',
                       @level1type = 'procedure',
                       @level1name = 'ps_UTIL_SELECT_CurrentSystemTime' 

--*
USE tempdb
go
SELECT   *
FROM ::fn_listextendedproperty (NULL, 'user', 'dbo', 'procedure', NULL, NULL, NULL)


--*
SELECT   *
FROM   ::fn_listextendedproperty (NULL, NULL, NULL, NULL, NULL, NULL, NULL)


--Stored Procedure Examples
--*
USE Northwind
go
CREATE PROCEDURE ps_Customers_SELECT_CompanyName
AS
SELECT CompanyName
FROM Customers
go
EXEC ps_Customers_SELECT_CompanyName


--*
USE Northwind
go
CREATE PROCEDURE ps_Customers_SELECT_CompanyNamePartial
@CompanyName nvarchar(40)
AS
SELECT CompanyName
FROM Customers
WHERE CompanyName LIKE @CompanyName+'%'
go
EXEC ps_Customers_SELECT_CompanyNamePartial 'A'


--*
USE Northwind
go
EXEC ps_Customers_SELECT_CompanyNamePartial 'Al'


--*
USE Northwind
go
CREATE PROCEDURE ps_Customers_SELECT_CompanyOrdersByDateRange
@CustomerID nchar(5),
@OrderDateStart datetime,
@OrderDateEnd datetime
AS
SELECT CompanyName,
       OrderDate
FROM Customers a
JOIN Orders b ON a.CustomerID = b.CustomerID
WHERE a.CustomerID = @CustomerID AND 
      b.OrderDate BETWEEN @OrderDateStart AND @OrderDateEnd
go
EXEC ps_Customers_SELECT_CompanyOrdersByDateRange 'ALFKI','1/1/97','1/1/98'

--*
USE Northwind
go
EXEC ps_Customers_SELECT_CompanyOrdersByDateRange @OrderDateEnd = '1/1/98', @CustomerID = 'ALFKI',@OrderDateStart = '1/1/97'


--*
USE Northwind
go
EXEC ps_Customers_SELECT_CompanyOrdersByDateRange @OrderDateEnd = '1/1/98', @OrderDateStart = '1/1/97'


--*
USE Northwind
go
ALTER PROCEDURE ps_Customers_SELECT_CompanyOrdersByDateRange
@CustomerID nchar(5) = NULL,
@OrderDateStart datetime,
@OrderDateEnd datetime
AS
SELECT CompanyName,
       OrderDate
FROM Customers a
JOIN Orders b ON a.CustomerID = b.CustomerID
WHERE (@CustomerID IS NULL OR a.CustomerID = @CustomerID) AND 
      b.OrderDate BETWEEN @OrderDateStart AND @OrderDateEnd
ORDER BY a.CompanyName
go
EXEC ps_Customers_SELECT_CompanyOrdersByDateRange @OrderDateEnd = '1/1/98', @OrderDateStart = '1/1/97'


--*
USE Northwind
go
CREATE PROCEDURE ps_Customers_SELECT_OrderByParameter
@SortColumn varchar(10)
AS
SELECT CustomerID,
       CASE @SortColumn WHEN 'Company' THEN CompanyName
                        WHEN 'Contact' THEN ContactName
       END AS SortColumn
FROM Customers
ORDER BY SortColumn


--*
USE Northwind
go
ps_Customers_SELECT_OrderByParameter 'Company'


--Modifying Data
--*
USE tempdb
go
CREATE TABLE Contacts
(
 Con_UniqueID smallint IDENTITY PRIMARY KEY,
 Con_FName varchar(30) NOT NULL,
 Con_LName varchar(30) NOT NULL,
 Con_Email varchar(40) NULL,
)


--*
USE tempdb
go
CREATE PROCEDURE ps_Contacts_INSERT
@Con_FName varchar(30),
@Con_LName varchar(30),
@Con_Email varchar(40) = NULL
AS
INSERT Contacts
(
 Con_FName,
 Con_LName,
 Con_Email
)
VALUES
(
 @Con_FName,
 @Con_LName,
 @Con_Email
)


--*
USE tempdb
go
EXEC ps_Contacts_INSERT 'Roger','Clemens','Roger@Rocket.com'

EXEC ps_Contacts_INSERT 'Pedro','Martinez'

EXEC ps_Contacts_INSERT @Con_Email = 'Nolan@5NoHitters.com',
                        @Con_LName = 'Ryan',
                        @Con_FName = 'Nolan'
 
SELECT Con_UniqueID,
       RTRIM(Con_FName)+' '+Con_LName AS ContactName,
       Con_Email
FROM Contacts
ORDER BY Con_LName


--*
USE tempdb
go
CREATE PROCEDURE ps_Contacts_UPDATE
@Con_UniqueID smallint,
@Con_FName varchar(30),
@Con_LName varchar(30),
@Con_Email varchar(40)
AS
UPDATE Contacts
SET Con_FName = @Con_FName,
    Con_LName = @Con_LName,
    Con_Email = @Con_Email
WHERE Con_UniqueID = @Con_UniqueID


--*
USE tempdb
go
EXEC ps_Contacts_UPDATE 1,'The Rocket','Clemens','Roger@Rocket.com'

EXEC ps_Contacts_UPDATE 2,'Pedro','Martinez','Pedro@BoSox.com'

EXEC ps_Contacts_UPDATE @Con_UniqueID = 3,
                        @Con_Email = 'Nolan@HallOfFame.com',
                        @Con_LName = 'Ryan',
                        @Con_FName = 'Nolan'

SELECT Con_UniqueID,
       RTRIM(Con_FName)+' '+Con_LName AS ContactName,
       Con_Email
FROM Contacts
ORDER BY Con_LName


--*
USE tempdb
go
CREATE TABLE Contacts_Target
(
 Con_UniqueID smallint IDENTITY PRIMARY KEY,
 Con_FName varchar(30) NOT NULL,
 Con_LName varchar(30) NOT NULL,
 Con_Email varchar(40) NULL,
)


--*
USE tempdb
go
CREATE PROCEDURE ps_Contacts_SELECT
AS
SELECT Con_UniqueID,
       Con_FName,
       Con_LName,
       Con_Email
FROM Contacts


--*
USE tempdb
go
SET IDENTITY_INSERT Contacts_Target ON
GO
INSERT Contacts_Target (Con_UniqueID,Con_FName,Con_LName,Con_Email)
EXEC ps_Contacts_SELECT

SELECT * FROM Contacts_Target


--*
USE tempdb
go
SET IDENTITY_INSERT Contacts_Target ON
GO
INSERT Contacts_Target
EXEC ps_Contacts_SELECT


--*
CREATE TABLE ContactsAddress
(
 ConAdd_UniqueID smallint IDENTITY PRIMARY KEY,
 Con_UniqueID smallint FOREIGN KEY REFERENCES Contacts (Con_UniqueID) NOT NULL,
 ConAdd_Address varchar(20) NOT NULL,
 ConAdd_City varchar(20) NOT NULL,
 ConAdd_State char(2) NOT NULL
)



--*
ALTER PROCEDURE ps_Contacts_INSERT
@Con_FName varchar(30),
@Con_LName varchar(30),
@Con_Email varchar(40) = NULL,
@Con_UniqueID int OUTPUT
AS
INSERT Contacts
(
 Con_FName,
 Con_LName,
 Con_Email
)
VALUES
(
 @Con_FName,
 @Con_LName,
 @Con_Email
)

SET @Con_UniqueID = @@IDENTITY


--*
DECLARE @Con_UniqueID int

EXEC ps_Contacts_INSERT 'Jeff',
                        'Bagwell',
                        'jeff@Astros.com',
                        @Con_UniqueID OUTPUT

PRINT CAST(@Con_UniqueID AS varchar(10))


--*
DECLARE @ID int

EXEC ps_Contacts_INSERT 'Jeff',
                        'Bagwell',
                        'jeff@Astros.com',
                        @ID OUTPUT

PRINT CAST(@ID AS varchar(10))


--*
CREATE PROCEDURE ps_ContactsAddress_INSERT
@Con_UniqueID int,
@ConAdd_Address varchar(20),
@ConAdd_City varchar(20),
@ConAdd_State char(2)
AS
INSERT ContactsAddress
(
 Con_UniqueID,
 ConAdd_Address,
 ConAdd_City,
 ConAdd_State
)
VALUES
(
 @Con_UniqueID,
 @ConAdd_Address,
 @ConAdd_City,
 @ConAdd_State
)


--*
DECLARE @Con_UniqueID int

--Create Parent Record in Contacts
EXEC ps_Contacts_INSERT 'Jeff',
                        'Bagwell',
                        'jeff@Astros.com',
                        @Con_UniqueID OUTPUT

--Create Child Record in ContactsAddress
EXEC ps_ContactsAddress_INSERT @Con_UniqueID,
                               'EnronField',
                               'Houston',
                               'TX'

SELECT a.Con_FName,
       b.ConAdd_Address
FROM Contacts a
JOIN ContactsAddress b ON a.Con_UniqueID = b.Con_UniqueID


--Dynamic SQL
--*
USE Northwind
go
CREATE PROCEDURE ps_Customers_SELECT_TopN
@TopValue smallint
AS

EXEC('SELECT TOP '+ @TopValue + ' CompanyName FROM Customers ORDER BY CompanyName')


--*
USE Northwind
go
EXEC ps_Customers_SELECT_TopN 5


--*
USE Northwind
go
CREATE PROCEDURE ps_UTIL_SELECT_FromProvidedName
@TableName nvarchar(128)
AS
EXEC('SELECT * FROM '+ @TableName)


--*
EXEC ps_UTIL_SELECT_FromProvidedName 'Region'


---------------Error Handling
--*
USE tempdb
go
CREATE PROCEDURE ps_FatalError_SELECT
AS
SELECT * FROM NonExistentTable
PRINT 'Fatal Error'
go
EXEC ps_FatalError_SELECT


--*
USE tempdb
go
CREATE TABLE NonFatal 
(
 Column1 int IDENTITY,
 Column2 int NOT NULL
)


--*
USE tempdb
go
CREATE PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
INSERT NonFatal VALUES (@Column2)
PRINT 'NonFatal'
go
EXEC ps_NonFatal_INSERT


--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
INSERT NonFatal VALUES (@Column2)
IF @@ERROR <> 0
 BEGIN
  PRINT 'Error Occured'
 END


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT 111


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
INSERT NonFatal VALUES (@Column2)
IF @@ERROR <> 0
 BEGIN
  PRINT @@Error
 END


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
DECLARE @ErrorMsgID int

INSERT NonFatal VALUES (@Column2)
SET @ErrorMsgID = @@ERROR
IF @ErrorMsgID <> 0
 BEGIN
  PRINT @ErrorMsgID
 END
go


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--RAISERROR
--*
RAISERROR ('An error occured updating the NonFatal table',10,1)

--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
DECLARE @ErrorMsgID int

INSERT NonFatal VALUES (@Column2)
SET @ErrorMsgID = @@ERROR
IF @ErrorMsgID <> 0
 BEGIN
  RAISERROR ('An error occured updating the NonFatal table',10,1)
 END


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
DECLARE @ErrorMsgID int

INSERT NonFatal VALUES (@Column2)
SET @ErrorMsgID = @@ERROR
IF @ErrorMsgID <> 0
 BEGIN
  RAISERROR ('An error occured updating the NonFatal table (%d)',10,1,@ErrorMsgID)
 END


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
DECLARE @ErrorMsgID int,
        @UserName sysname
SET @UserName = USER_NAME()

INSERT NonFatal VALUES (@Column2)
SET @ErrorMsgID = @@ERROR
IF @ErrorMsgID <> 0
 BEGIN
  RAISERROR ('An error occured updating the NonFatal table (%d),(%s)',16,2,@ErrorMsgID,@UserName)
 END


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--*
sp_addmessage @msgnum = 50001, 
              @severity = 17, 
              @msgtext = 'An error occured updating the NonFatal table' 


--*
RAISERROR (50001,10,1)


--Client 
--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL
AS
SET NOCOUNT ON
DECLARE @ErrorMsgID int,
        @UserName sysname
SET @UserName = USER_NAME()

INSERT NonFatal VALUES (@Column2)
SET @ErrorMsgID = @@ERROR
IF @ErrorMsgID <> 0
 BEGIN
  RAISERROR (50001,17,1)
 END
go


--*
USE tempdb
go
EXEC ps_NonFatal_INSERT


--*
USE tempdb
go
ALTER PROCEDURE ps_NonFatal_INSERT
@Column2 int = NULL,
@ErrorCode tinyint OUTPUT
AS
DECLARE @ErrorMsgID int,
        @UserName sysname
SET @UserName = USER_NAME()

INSERT NonFatal VALUES (@Column2)
IF @@ERROR <> 0
 SET @ErrorCode =  99
ELSE
 SET @ErrorCode =  0
go
--------------------------------------*End of Ch 11 - User-Defined Stored Procedures