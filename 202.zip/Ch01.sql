--------------------------------------*Ch 1 - Transact-SQL Overview
/*
                       --> READ ME FIRST <--

 The examples in this file should be executed one at a time (as listed
 in the book). To execute an example, highlight the associated statements
 and click the Run button on the toolbar. You can also press CTRL+E to 
 execute a statement.
*/


--ANSI versus T-SQL Example

--*
USE tempdb
go
CREATE TABLE Customers 
(
 Cus_UniqueID int IDENTITY(1,1) PRIMARY KEY, 
 Cus_Name varchar(30)
)


--*
USE tempdb
go
INSERT Customers (Cus_Name)VALUES ('Big Red Machine Co.')

SELECT Cus_UniqueID, Cus_Name
FROM Customers


--*
USE tempdb
go
CREATE TABLE Customers_ANSI 
(
 Cus_UniqueID int PRIMARY KEY, 
 Cus_Name varchar(30)
)


--*
USE tempdb
go
INSERT Customers_ANSI
SELECT COALESCE(MAX(Cus_UniqueID)+1,1),
       'Big Red Machine Co.'
FROM Customers_ANSI

SELECT Cus_UniqueID, Cus_Name
FROM Customers_ANSI

--------------------------------------*End of Ch 1 - Transact-SQL Overview
